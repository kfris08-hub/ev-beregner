EV Beregner Modelside 2.0
- 186 modelsider med beregninger, DK1/DK2, benzin/diesel og interne alternativer.
- Grafiske bilillustrationer er originale og mærket ILLUSTRATION. De er ikke produktfotos.
- Produktfotos bør kun tilføjes med dokumenteret tilladelse/licens fra producent/pressebank.
- Eksisterende root index.html, energiprislogik, fuel-prices.json, favicon og sitemap er bevaret.
- .github workflow er bevidst ikke pakket med, så installationen ikke forsøger at overskrive workflowet, der allerede er oprettet manuelt.
